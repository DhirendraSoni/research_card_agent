
import os
import json
import streamlit as st
from dotenv import load_dotenv
from langchain_core.messages import HumanMessage, AIMessage

# Import paths assume a structure like: app/agents/* and app/models/*; adjust if needed.
try:
    from agents.graph import build_graph
    from agents.state import AgentState
    from agents.tools import load_profile, get_default_address
    from models.bedrock_llm import get_bedrock_llm
except Exception:
    # Fallback relative to this file if living under app/
    import sys
    THIS_DIR = os.path.dirname(os.path.abspath(__file__))
    PARENT = os.path.abspath(os.path.join(THIS_DIR, ".."))
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    from agents.graph import build_graph
    from agents.state import AgentState
    from agents.tools import load_profile, get_default_address
    from models.bedrock_llm import get_bedrock_llm

load_dotenv()

# ---------- Page config & style ----------
st.set_page_config(page_title="Card Replacement Autonomous Agent", page_icon="💳", layout="wide")

PRIMARY = "#4F46E5"
SUCCESS = "#10B981"
WARN = "#F59E0B"

st.markdown(f"""
    <style>
    .big-title {{
        font-size: 2rem;
        font-weight: 800;
        margin-bottom: .25rem;
    }}
    .subtitle {{
        color: #6b7280;
        margin-bottom: 1rem;
    }}
    .pill {{
        display: inline-block;
        padding: .25rem .6rem;
        border-radius: 999px;
        background: {PRIMARY}20;
        color: {PRIMARY};
        font-weight: 600;
        font-size: .85rem;
    }}
    .step {{
        border-left: 4px solid {PRIMARY};
        background: #f9fafb;
        padding: .75rem;
        border-radius: .75rem;
        margin-bottom: .5rem;
    }}
    .done {{ border-left-color: {SUCCESS}; }}
    .todo {{ border-left-color: #9ca3af; }}
    .ask  {{ border-left-color: {WARN}; }}
    .ok   {{ color: {SUCCESS}; font-weight: 600; }}
    .need {{ color: {WARN}; font-weight: 600; }}
    .final-box {{
        border: 1px solid #e5e7eb;
        background: #f0fdf4;
        padding: 1rem;
        border-radius: .75rem;
    }}
    </style>
""", unsafe_allow_html=True)

st.markdown('<div class="big-title">💳 Card Replacement Autonomous Agent</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">Autonomous: plan → think → decide → act. I will ask for anything missing.</div>', unsafe_allow_html=True)
st.markdown('<span class="pill">LangGraph · LangChain · AWS Bedrock</span>', unsafe_allow_html=True)

# ---------- Sidebar: profile & settings ----------
profile = load_profile()
st.sidebar.header("👤 User")
st.sidebar.write(f"**User ID:** `{profile.get('user_id', '-')}`")

cards = profile.get("cards", [])
if cards:
    st.sidebar.subheader("💼 Cards on file")
    st.sidebar.dataframe(
        { 
            "card_id":[c.get("card_id","") for c in cards],
            "type":[c.get("type","") for c in cards],
            "masked":[c.get("masked_number","") for c in cards],
            "status":[c.get("status","") for c in cards]
        },
        use_container_width=True
    )

st.sidebar.subheader("🏠 Default Address")
try:
    st.sidebar.caption(get_default_address())
except Exception:
    st.sidebar.caption("—")

debug = st.sidebar.toggle("Show plan/think/events", value=os.getenv("AGENT_DEBUG","false").lower()=="true")

# ---------- Session init ----------
if "graph" not in st.session_state:
    try:
        llm = get_bedrock_llm()
    except Exception as e:
        st.error(f"LLM init failed: {e}")
        st.stop()
    st.session_state.graph = build_graph(llm)

if "state" not in st.session_state:
    st.session_state.state = AgentState(
        user_query="",
        messages=[],
        thoughts=[],
        events=[],
        address_confirmed=None,
        delivery_confirmed=None,
    )

# ---------- Main layout ----------
left, right = st.columns([0.6, 0.4], gap="large")

with left:
    # Chat input
    with st.form("chat", border=False):
        user_msg = st.text_input(
            "Ask me to replace or cancel a card (e.g., “Replace CRD-001 due to damage and ship to my saved address.”)",
            value=""
        )
        submit_chat = st.form_submit_button("Send")
        if submit_chat and user_msg.strip():
            st.session_state.state["user_query"] = user_msg.strip()
            st.session_state.state["messages"] = (st.session_state.state.get("messages") or []) + [HumanMessage(content=user_msg.strip())]
            out = st.session_state.graph.invoke(st.session_state.state)
            for k,v in out.items():
                st.session_state.state[k] = v

    # Transcript
    for m in st.session_state.state.get("messages", []):
        if isinstance(m, HumanMessage):
            with st.chat_message("user"):
                st.write(m.content)
        elif isinstance(m, AIMessage):
            with st.chat_message("assistant"):
                st.write(m.content)

    # Guided "missing info" form
    qs = st.session_state.state.get("next_questions") or []
    need_reason = ("reason" not in st.session_state.state) or (not st.session_state.state.get("reason"))
    need_address = (st.session_state.state.get("address_confirmed") is not True)
    need_delivery = (st.session_state.state.get("delivery_confirmed") is not True)
    need_card = ("selected_card_id" not in st.session_state.state) or (not st.session_state.state.get("selected_card_id"))

    if qs or need_reason or need_address or need_delivery or need_card:
        st.markdown("### 🔎 I need a few details")
        if qs:
            for q in qs:
                st.markdown(f"- {q}")

        with st.form("details_form", border=True):
            # Card selection
            if need_card:
                choices = [f"{c.get('card_id','')} · {c.get('type','')} ({c.get('masked_number','')})" for c in cards]
                sel = st.selectbox("Select a card", choices, index=0 if choices else None, placeholder="Choose a card")
                selected_card_id = sel.split(" · ")[0] if sel else None
            else:
                selected_card_id = st.session_state.state.get("selected_card_id")

            # Reason
            if need_reason:
                reason = st.text_input("Reason for replacement", value=st.session_state.state.get("reason",""))
            else:
                reason = st.session_state.state.get("reason")

            # Address confirmation
            try:
                default_addr = get_default_address()
            except Exception:
                default_addr = ""
            st.caption(f"Saved address: {default_addr or '—'}")
            if need_address:
                addr_confirm = st.checkbox("Ship to saved address?", value=False)
                manual_addr = st.text_input("Or type a different delivery address (optional)")
            else:
                addr_confirm = True
                manual_addr = st.session_state.state.get("address","")

            # Final delivery confirmation
            if need_delivery:
                deliver_ok = st.checkbox("Confirm to dispatch replacement to the confirmed address", value=False)
            else:
                deliver_ok = True

            submit_details = st.form_submit_button("Continue")
            if submit_details:
                # push user-provided details into state and re-run graph
                if selected_card_id:
                    st.session_state.state["selected_card_id"] = selected_card_id
                if reason:
                    st.session_state.state["reason"] = reason.strip()

                if need_address:
                    if addr_confirm and not (manual_addr or "").strip():
                        if default_addr:
                            st.session_state.state["address"] = default_addr
                            st.session_state.state["address_confirmed"] = True
                        else:
                            st.session_state.state["address_confirmed"] = False
                    elif (manual_addr or "").strip():
                        st.session_state.state["address"] = manual_addr.strip()
                        st.session_state.state["address_confirmed"] = True
                    else:
                        st.session_state.state["address_confirmed"] = False

                if need_delivery:
                    st.session_state.state["delivery_confirmed"] = bool(deliver_ok)

                # Re-enter the graph for the next step/decision
                st.session_state.state["user_query"] = "(user provided missing details)"
                out = st.session_state.graph.invoke(st.session_state.state)
                for k,v in out.items():
                    st.session_state.state[k] = v
                st.experimental_rerun()

    # Final success message
    if st.session_state.state.get("final_message"):
        st.markdown('<div class="final-box">✅ ' + st.session_state.state["final_message"] + '</div>', unsafe_allow_html=True)

with right:
    st.markdown("### 📋 Progress")
    intent = st.session_state.state.get("intent")
    selected_card_id = st.session_state.state.get("selected_card_id")
    reason = st.session_state.state.get("reason")
    address = st.session_state.state.get("address")
    addr_ok = st.session_state.state.get("address_confirmed")
    del_ok = st.session_state.state.get("delivery_confirmed")

    st.markdown(f"""
      <div class="step {'done' if intent not in (None, 'other') else 'todo'}">
        <b>Intent</b>: {'<span class="ok">✔ ' + str(intent) + '</span>' if intent else '<span class="need">• detect</span>'}
      </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
      <div class="step {'ask' if not selected_card_id else 'done'}">
        <b>Card selected</b>: {('<span class="ok">✔ ' + selected_card_id + '</span>') if selected_card_id else '<span class="need">• select</span>'}
      </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
      <div class="step {'ask' if not reason else 'done'}">
        <b>Reason</b>: {('<span class="ok">✔ provided</span>') if reason else '<span class="need">• provide</span>'}
      </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
      <div class="step {'ask' if not (addr_ok and address) else 'done'}">
        <b>Address</b>: {('<span class="ok">✔ confirmed</span>') if (addr_ok and address) else '<span class="need">• confirm</span>'}
      </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
      <div class="step {'ask' if not del_ok else 'done'}">
        <b>Dispatch Confirmation</b>: {('<span class="ok">✔ confirmed</span>') if del_ok else '<span class="need">• confirm</span>'}
      </div>
    """, unsafe_allow_html=True)

    if debug:
        st.divider()
        st.subheader("🧠 Agent internals")
        if st.session_state.state.get("plan"):
            st.markdown("**Plan**")
            st.code(st.session_state.state["plan"])

        if st.session_state.state.get("thoughts"):
            st.markdown("**Think**")
            for i, t in enumerate(st.session_state.state["thoughts"], start=1):
                st.code(f"[{i}] {t}")

        if st.session_state.state.get("events"):
            st.markdown("**Events**")
            st.code("\n".join(st.session_state.state["events"]))
